import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import dayjs from "dayjs";
import { getSchedules } from "../../../../../../../redux/actions/schedules";
const ScheduleOverview = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getSchedules());
  }, []);
  const schedules = useSelector(state => state.schedules);
  const [currentWeekIndex, setCurrentWeekIndex] = useState(-1);
  const weekOfYear = require("dayjs/plugin/weekOfYear");
  dayjs.extend(weekOfYear);
  const currentWeek = dayjs(new Date()).week();
  const index = schedules
    .map(schedule => {
      console.log(schedule.weekNumber);
      return schedule.weekNumber;
    })
    .indexOf(currentWeek);
  console.log(index);
  setCurrentWeekIndex(index);
  if (currentWeekIndex === -1) {
    return null;
  } else {
    return (
      <>
        <div className="schedule__overview-title">
          Twój plan na {currentWeekIndex} tydzień:
        </div>
        <div className="schedule__overview-content-container">
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Poniedziałek
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].monday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].monday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].monday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].monday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].monday[4]}
            </div>
          </div>
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Wtorek
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].tuesday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].tuesday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].tuesday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].tuesday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].tuesday[4]}
            </div>
          </div>
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Środa
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].wednesday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].wednesday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].wednesday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].wednesday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].wednesday[4]}
            </div>
          </div>
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Czwartek
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].thrusday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].thrusday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].thrusday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].thrusday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].thrusday[4]}
            </div>
          </div>
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Piątek
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].friday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].friday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].friday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].friday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].friday[4]}
            </div>
          </div>
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Sobota
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].satruday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].satruday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].satruday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].satruday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].satruday[4]}
            </div>
          </div>
          <div className="schedule__overview-content-day">
            <div className="schedule__overview-content-element-title">
              Niedziela
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].sunday[0]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].sunday[1]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].sunday[2]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].sunday[3]}
            </div>
            <div className="schedule__overview-content-element">
              {schedules[currentWeekIndex].sunday[4]}
            </div>
          </div>
        </div>
        <div className="schedule__overview-content-nav">
          <div className="schedule__overview-content-nav-element prev">
            <span>&laquo;</span>
            <span>poprzedni</span>
          </div>
          <div className="schedule__overview-content-nav-element next">
            <span>następny</span>
            <span>&raquo;</span>
          </div>
        </div>
      </>
    );
  }
};
export default ScheduleOverview;
