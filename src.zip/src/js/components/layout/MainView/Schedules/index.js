import React from "react";

const Schedules = () => {
  return (
    <div>
      <p>Schedules</p>
    </div>
  );
};

export default Schedules;
