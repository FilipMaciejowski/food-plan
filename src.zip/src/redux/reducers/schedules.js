import {} from "../actions/schedules";

const schedules = (state = "", { type, payload }) => {
  switch (type) {
    default: {
      return state;
    }
  }
};

export default schedules;
