import { SCHEDULE_FETCHED, ADD_SCHEDULE } from "../actions/schedules";

const schedules = (state = [], { type, payload }) => {
  switch (type) {
    case SCHEDULE_FETCHED:
      return [...state, payload];
    case ADD_SCHEDULE:
      return [...state, payload];
    default: {
      return state;
    }
  }
};

export default schedules;
